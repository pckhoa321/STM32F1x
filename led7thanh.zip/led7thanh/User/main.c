#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
void GPIOC_Configure(){
	//cap clock 
	RCC -> APB2ENR |= 0x10;
	GPIOC -> CRL   |= 0xF0000000;
	GPIOC -> CRL   |= 0x03333333;
}
void delay(int time){
	for(int i = 0; i< time; i++){
		for(int j = 0; j< 0x2AFF; j++);
	}
}
int  Led7Seg[] = {0xC0, 0xF9, 0xA4, 0xB0 , 0x99, 0x92, 0x82, 0x78, 0x80 , 0x90};
int main(){
	GPIOC_Configure();
	while(1){
		for(int i = 0; i < 10; i+=2){
			GPIOC -> ODR = Led7Seg[i];
			delay(50);
		}
	}
}